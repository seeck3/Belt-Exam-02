export class Review {
  _id: string;
  star: number;
  name: string;
  review: string;
}
