const movieController = require('./movie.controller');

module.exports = {

  movieController,
};
