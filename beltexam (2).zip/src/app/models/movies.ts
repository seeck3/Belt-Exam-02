export class Movie {
  _id: string;
  title: string;
  stars: number;
  name: string;
  reviews: string;
}
